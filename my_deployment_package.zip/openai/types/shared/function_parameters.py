# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict

__all__ = ["FunctionParameters"]

FunctionParameters = Dict[str, object]
